Configuration Deploy-DomainServices
{
    Param
    (
        [Parameter(Mandatory)]
        [String] $domainFQDN,
        [String] $domainSuffix,

        [Parameter(Mandatory)]
        [String] $fslogixProfileSizeZipUrl,
        
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential] $adminCredential
    )

    [String] $domainName = $domainFQDN.Split('.')[0]
    if ($domainName.Length -gt 15) {
        $domainName = $domainName.Substring(0,15)
    }

    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
    Import-DscResource -ModuleName 'ActiveDirectoryDsc'
    Import-DscResource -ModuleName 'ComputerManagementDsc'
    Import-DscResource -ModuleName 'NetworkingDsc'

    # Create the NetBIOS name and domain credentials based on the domain FQDN
    [String] $domainNetBIOSName = (Get-NetBIOSName -DomainFQDN $domainFQDN)
    [System.Management.Automation.PSCredential] $domainCredential = New-Object System.Management.Automation.PSCredential ("${domainNetBIOSName}\$($adminCredential.UserName)", $adminCredential.Password)

    $interface = Get-NetAdapter | Where-Object Name -Like 'Network' | Select-Object -First 1
        if (-not $interface) {
    $interface = Get-NetAdapter | Where-Object Name -Like 'Ethernet' | Select-Object -First 1
}
    $interfaceAlias = $($interface.Name)

    Node localhost
    {
        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        WindowsFeature InstallDNS 
        { 
            Ensure = 'Present'
            Name = 'DNS'
        }

        WindowsFeature InstallDNSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-DNS-Server'
            DependsOn = '[WindowsFeature]InstallDNS'
        }

        DnsServerAddress SetDNS
        { 
            Address = '127.0.0.1'
            InterfaceAlias = $interfaceAlias
            AddressFamily = 'IPv4'
            DependsOn = '[WindowsFeature]InstallDNS'
        }

        WindowsFeature InstallADDS
        {
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
            DependsOn = '[WindowsFeature]InstallDNS'
        }

        WindowsFeature InstallADDSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-ADDS-Tools'
            DependsOn = '[WindowsFeature]InstallADDS'
        }
        
        WindowsFeature InstallGPMC
        {
            Ensure = 'Present'
            Name = 'GPMC'
            DependsOn = '[WindowsFeature]InstallADDS'
        }

        ADDomain CreateADForest
        {
            DomainName = $domainFQDN
            Credential = $domainCredential
            SafemodeAdministratorPassword = $domainCredential
            ForestMode = 'WinThreshold'
            DatabasePath = 'C:\NTDS'
            LogPath = 'C:\NTDS'
            SysvolPath = 'C:\SYSVOL'
            DependsOn = '[DnsServerAddress]SetDNS', '[WindowsFeature]InstallADDS'
        }

        PendingReboot RebootAfterCreatingADForest
        {
            Name = 'RebootAfterCreatingADForest'
            DependsOn = "[ADDomain]CreateADForest"
        }
        WaitForADDomain WaitForDomainController
        {
            DomainName = $domainFQDN
            WaitTimeout = 600
            RestartCount = 3
            Credential = $domainCredential
            WaitForValidCredentials = $true
            DependsOn = "[PendingReboot]RebootAfterCreatingADForest"
        }
# Start neuer Block mit OUs
        ADOrganizationalUnit OU_EntraSync {
            Name        = 'EntraSync'
            Path        = "DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[WaitForADDomain]WaitForDomainController'
        }

        ADOrganizationalUnit OU_NoEntraSync {
            Name        = 'NoEntraSync'
            Path        = "DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[WaitForADDomain]WaitForDomainController'
        }

        ADOrganizationalUnit OU_Users {
            Name        = 'Users'
            Path        = "OU=EntraSync,DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[ADOrganizationalUnit]OU_EntraSync'
        }

        ADOrganizationalUnit OU_Groups {
            Name        = 'Groups'
            Path        = "OU=EntraSync,DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[ADOrganizationalUnit]OU_EntraSync'
        }
        ADOrganizationalUnit OU_Server {
            Name        = 'Server'
            Path        = "OU=EntraSync,DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[ADOrganizationalUnit]OU_EntraSync'
        }

        ADOrganizationalUnit OU_NoEntraSyncUsers {
            Name        = 'Users'
            Path        = "OU=NoEntraSync,DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[ADOrganizationalUnit]OU_NoEntraSync'
        }

        ADOrganizationalUnit OU_NoEntraSyncGroups {
            Name        = 'Groups'
            Path        = "OU=NoEntraSync,DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[ADOrganizationalUnit]OU_NoEntraSync'
        }

        ADOrganizationalUnit OU_NoEntraSyncStorage {
            Name        = 'Storage'
            Path        = "OU=NoEntraSync,DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[ADOrganizationalUnit]OU_NoEntraSync'
        }
# neuer Block mit OU's ENDE

        ADGroup AvdAccess {
            GroupName     = 'AvdAccess'
            Path          = "OU=Groups,OU=EntraSync,DC=$domainName,DC=local"
            Ensure        = 'Present'
            GroupScope    = 'Global'
            Category = 'Security'
            Credential    = $domainCredential
            DependsOn     = '[ADOrganizationalUnit]OU_Groups'
        }

        ADGroup AvdProfileAccess {
            GroupName     = 'AvdProfileAccess'
            Path          = "OU=Groups,OU=EntraSync,DC=$domainName,DC=local"
            Ensure        = 'Present'
            GroupScope    = 'Global'
            Category = 'Security'
            Credential    = $domainCredential
            DependsOn     = '[ADOrganizationalUnit]OU_Groups'
        }
        
        Script SetDnsForwarder
        {
            DependsOn = '[WaitForADDomain]WaitForDomainController'
            GetScript = {
                @{ Result = ((Get-DnsServerForwarder -ErrorAction SilentlyContinue).IPAddress.IPAddressToString -join ',') }
            }
            TestScript = {
                $fwd = (Get-DnsServerForwarder -ErrorAction SilentlyContinue).IPAddress.IPAddressToString
                return ($fwd -contains '168.63.129.16')
            }
            SetScript = {
                Set-DnsServerForwarder -IPAddress '168.63.129.16' -UseRootHint $false
            }
        }

        Script ConfigureFSLogixProfileSizeGpo
        {
            DependsOn = '[WaitForADDomain]WaitForDomainController', '[ADOrganizationalUnit]OU_Server', '[WindowsFeature]InstallGPMC', '[ADGroup]AvdProfileAccess', '[Script]SetDnsForwarder'
            GetScript = {
                $gpo = Get-GPO -Name 'FSLogix' -ErrorAction SilentlyContinue
                return @{ Result = if ($gpo) { 'Present' } else { 'Absent' } }
            }
            TestScript = {
                Import-Module GroupPolicy -ErrorAction Stop

                $domainDn = 'DC=' + (($using:domainFQDN -split '\.') -join ',DC=')
                $targetOu = "OU=Server,OU=EntraSync,$domainDn"
                $gpoName = 'FSLogix'

                $gpo = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
                if (-not $gpo) { return $false }

                $inheritance = Get-GPInheritance -Target $targetOu -ErrorAction SilentlyContinue
                if (-not $inheritance) { return $false }

                return ($inheritance.GpoLinks | Where-Object { $_.DisplayName -eq $gpoName }) -ne $null
            }
            SetScript = {
                Import-Module GroupPolicy -ErrorAction Stop

                $domainDn = 'DC=' + (($using:domainFQDN -split '\.') -join ',DC=')
                $targetOu = "OU=Server,OU=EntraSync,$domainDn"
                $gpoName = 'FSLogix'
                $FSLogixzipUrl = $using:fslogixProfileSizeZipUrl
                $FSLogixzipFile = 'C:\Temp\FSLogixAvd.zip'
                $extractPath = 'C:\Temp\FSLogix'

                New-Item -Path 'C:\Temp' -ItemType Directory -Force | Out-Null
                New-Item -Path $extractPath -ItemType Directory -Force | Out-Null

                Invoke-WebRequest -Uri $FSLogixzipUrl -OutFile $FSLogixzipFile -UseBasicParsing
                Expand-Archive -Path $FSLogixzipFile -DestinationPath $extractPath -Force

                if (-not (Get-GPO -Name $gpoName -ErrorAction SilentlyContinue)) {
                    New-GPO -Name $gpoName | Out-Null
                }

                Import-GPO -BackupGpoName 'FSLogix' -TargetName $gpoName -Path $extractPath -CreateIfNeeded
                New-GPLink -Name $gpoName -Target $targetOu -LinkEnabled Yes -ErrorAction SilentlyContinue | Out-Null
                Set-GPLink -Name $gpoName -Target $targetOu -LinkEnabled Yes
            }
        }
    }
}

function Get-NetBIOSName {
    [OutputType([string])]
    param(
        [string] $domainFQDN
    )

    if ($domainFQDN.Contains('.')) {
        $length = $domainFQDN.IndexOf('.')
        if ( $length -ge 16) {
            $length = 15
        }
        return $domainFQDN.Substring(0, $length)
    }
    else {
        if ($domainFQDN.Length -gt 15) {
            return $domainFQDN.Substring(0, 15)
        }
        else {
            return $domainFQDN
        }
    }
}